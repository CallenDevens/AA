WordGenerator: generate a word set using dictionary (dict.txt), invoked by DataStructureTester

DataStructureTester: Given operations user would like to test to the class, print time cost on the console.

parameter: number of inital elements, number of add opearation, number of remove opearation,number of search opearation

Example java DataStructureTester 2000 3000 5000 500